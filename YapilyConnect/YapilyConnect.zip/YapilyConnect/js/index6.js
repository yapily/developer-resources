Yapily.onReady = () => {
  Yapily.Accordion.init();
}

window.addEventListener('DOMContentLoaded', () => {
  Yapily.onReady();
})
